/** Automatically generated file. DO NOT MODIFY */
package com.ssm.cyclists;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}